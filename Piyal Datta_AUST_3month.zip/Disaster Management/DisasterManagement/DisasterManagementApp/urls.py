from django.urls import path

from . import views
from .views import *

app_name = 'Disaster_Management'

urlpatterns = [
    path('register/', views.register, name='register'),
    path('registration/', views.registration, name='registration'),
    path('login/', views.login, name='login'),
    path('home/', views.home, name='home'),
    path('crisis/', views.crisis, name='crisis'),
    path('add_crisis/', views.add_crisis, name='add_crisis'),
    path('crisis_list/', views.crisis_list, name='crisis_list'),
    path('volunteer/', views.volunteer, name='volunteer'),
    path('inventory/', views.inventory, name='inventory'),
    path('donate_fund/', views.donate_fund, name='donate_fund'),
    path('fund/', views.fund, name='fund'),
    path('donate_relief/', views.donate_relief, name='donate_relief'),
    path('relief/', views.relief, name='relief'),
    path('donation/', views.donation, name='donation'),
]
