from django.db import models

# Create your models here.


# ===============  Register ==================>
class Register(models.Model):
    email = models.EmailField(primary_key=True)
    type = models.TextField()
    username = models.TextField()
    contact = models.IntegerField()
    password = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.email} - {self.type} - {self.username} - {self.contact} - {self.password}"


# ==========  Donation taka ===============>
class DonationTaka(models.Model):
    id = models.AutoField(primary_key=True)
    email = models.EmailField()
    fullname = models.TextField()
    date = models.CharField(max_length=15)
    contact = models.IntegerField()
    amount = models.FloatField()

    def __str__(self):
        return f"{self.id} - {self.email} - {self.fullname} - {self.date} - {self.contact} - {self.amount}"


# ==========  Donation relief ===============>
class DonationRelief(models.Model):
    id = models.AutoField(primary_key=True)
    email = models.EmailField()
    fullname = models.TextField()
    date = models.CharField(max_length=15)
    contact = models.IntegerField()
    relief = models.TextField()

    def __str__(self):
        return f"{self.id} - {self.email} - {self.fullname} - {self.date} - {self.contact} - {self.relief}"


# =============  Crisis  =================>
class Crisis(models.Model):
    id = models.AutoField(primary_key=True)
    fullname = models.TextField()
    crisis = models.TextField()
    location = models.CharField(max_length=255)
    title = models.CharField(max_length=100)
    image = models.ImageField()
    description = models.CharField(max_length=255)
    required = models.CharField(max_length=255)
    severity = models.TextField()

    def __str__(self):
        return f"{self.id} - {self.fullname} - {self.crisis} - {self.location} - {self.title} - {self.image} - {self.description} - {self.required} - {self.severity}"


# ============  Inventory  ===============>
class Inventory(models.Model):
    id = models.AutoField(primary_key=True)
    relief = models.TextField()
    image = models.ImageField()
    price = models.FloatField()

    def __str__(self):
        return f"{self.id} - {self.relief} - {self.image} - {self.price}"
