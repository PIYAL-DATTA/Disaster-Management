from django.db.models import Sum
from django.http import HttpResponse
from django.shortcuts import render
from .models import *
import re


# Create your views here.


#   Registration
def register(request):  # ====== Registration display =======================>
    return render(request, 'DisasterManagementApp/register.html')


def registration(request):  # =============  Registration ================>
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        type = request.POST.get('type')
        contact = request.POST.get('contact')
        password = request.POST.get('password')
        repeat_password = request.POST.get('repeat_password')
        if password != repeat_password or len(password) < 6:
            return render(request, 'DisasterManagementApp/register.html')

        # For contact validation ===================================>
        pattern = re.compile("(0|01)?[0-9]{11}")
        if not (pattern.match(contact)):
            return render(request, 'DisasterManagementApp/register.html')
        # For email validation =====================================>
        pattern = re.compile(r"^[\w\.\+\-]+\@[\w]+\.[a-z]{2,3}$")
        if not (pattern.match(email)):
            return render(request, 'DisasterManagementApp/register.html')

        # db duplicate checking ====================================>
        account = Register.objects.all()
        for x in account:
            if email == x.email:
                return render(request, 'DisasterManagementApp/register.html')
        # End of db duplicate checking ======================================>

        # Create Edited User entry in the database using the User model
        account = Register(email=email, type=type, username=username, contact=contact, password=password)
        account.save()

        user = Register.objects.all()
        context = {'userlist': user}
        return render(request, 'DisasterManagementApp/volunteer.html', context)
    else:
        return render(request, 'DisasterManagementApp/register.html')


#   Login
def login(request):  # ============== Login display ======================>
    return render(request, 'DisasterManagementApp/login.html')


#   Home
def home(request):  # ============== Home display ======================>
    total_volunteer = Register.objects.count()
    total_donation = DonationTaka.objects.aggregate(Sum('amount'))
    # Extract the sum value or set it to 0 if no donations exist
    total_donation = total_donation.get('amount__sum', 0)
    context = {'total_volunteer': total_volunteer, 'total_donation': total_donation}
    return render(request, 'DisasterManagementApp/home.html', context)


#   crisis
def crisis(request):  # ============== crisis display ====================>
    crisis_list = Crisis.objects.all()
    context = {'crisis_list': crisis_list}
    return render(request, 'DisasterManagementApp/crisis.html', context)


#   add_crisis
def add_crisis(request):  # ============== add_crisis display =================>
    return render(request, 'DisasterManagementApp/add_crisis.html')


def crisis_list(request):  # ===================== Crisis List =======================>
    fullname = request.POST.get('fullname')
    crisis = request.POST.get('crisis')
    location = request.POST.get('location')
    title = request.POST.get('title')
    image = request.POST.get('image')
    description = request.POST.get('description')
    required = request.POST.get('required')
    severity = request.POST.get('severity')

    # Create Edited User entry in the database using the User model
    acc = Crisis(fullname=fullname, crisis=crisis, location=location, title=title, image=image, description=description, required=required, severity=severity)
    acc.save()

    crisis_list = Crisis.objects.all()
    context = {'crisis_list': crisis_list}
    return render(request, 'DisasterManagementApp/crisis.html', context)


#   volunteer
def volunteer(request):  # ============== volunteer display ==================>
    user = Register.objects.all()
    context = {'userlist': user}
    return render(request, 'DisasterManagementApp/volunteer.html', context)


#   inventory
def inventory(request):  # ============== inventory display ==================>
    goods = DonationRelief.objects.all()
    context = {'goods': goods}
    return render(request, 'DisasterManagementApp/inventory.html', context)


#   donate_fund
def donate_fund(request):  # ============= donate_fund display =================>
    return render(request, 'DisasterManagementApp/donate_fund.html')


def fund(request):  # ===================== fund form =======================>
    fullname = request.POST.get('fullname')
    email = request.POST.get('email')
    contact = request.POST.get('contact')
    date = request.POST.get('date')
    amount = request.POST.get('amount')
    # # For empty check =========================================>
    # if not name:
    #     return render(request, 'webapp/error.html')
    # if not email:
    #     return render(request, 'webapp/error.html')
    # if not contact:
    #     return render(request, 'webapp/error.html')
    # if not password:
    #     return render(request, 'webapp/error.html')

    # For contact validation ===================================>
    pattern = re.compile("(0|01)?[0-9]{11}")
    if not (pattern.match(contact)):
        return render(request, 'DisasterManagementApp/donate_fund.html')
    # For email validation =====================================>
    pattern = re.compile(r"^[\w\.\+\-]+\@[\w]+\.[a-z]{2,3}$")
    if not (pattern.match(email)):
        return render(request, 'DisasterManagementApp/donate_fund.html')

    # Create Edited User entry in the database using the User model
    donate = DonationTaka(email=email, fullname=fullname, date=date, contact=contact, amount=amount)
    donate.save()

    user = DonationTaka.objects.all()
    context = {'userlist': user}
    return render(request, 'DisasterManagementApp/donation.html', context)


#   donate_relief
def donate_relief(request):  # =========== donate_relief display =================>
    return render(request, 'DisasterManagementApp/donate_relief.html')


def relief(request):  # ===================== Relief form =======================>
    fullname = request.POST.get('fullname')
    email = request.POST.get('email')
    contact = request.POST.get('contact')
    date = request.POST.get('date')
    relief = request.POST.get('relief')

    # For contact validation ===================================>
    pattern = re.compile("(0|01)?[0-9]{11}")
    if not (pattern.match(contact)):
        return render(request, 'DisasterManagementApp/donate_relief.html')
    # For email validation =====================================>
    pattern = re.compile(r"^[\w\.\+\-]+\@[\w]+\.[a-z]{2,3}$")
    if not (pattern.match(email)):
        return render(request, 'DisasterManagementApp/donate_relief.html')

    # Create Edited User entry in the database using the User model
    donate = DonationRelief(email=email, fullname=fullname, date=date, contact=contact, relief=relief)
    donate.save()

    goods = DonationRelief.objects.all()
    context = {'goods': goods}
    return render(request, 'DisasterManagementApp/inventory.html', context)


#   donation
def donation(request):  # ================== donation display ========================>
    user = DonationTaka.objects.all()
    context = {'userlist': user}
    return render(request, 'DisasterManagementApp/donation.html', context)
