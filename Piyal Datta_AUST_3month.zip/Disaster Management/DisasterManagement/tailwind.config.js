/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./DisasterManagementApp/templates/DisasterManagementApp/**/*.{html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}

